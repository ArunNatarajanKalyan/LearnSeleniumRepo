package Week2.Day2;



	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.support.ui.Select;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import java.time.Duration;

	
	
	public class CreateLead2 {
		public static void main(String[] args)  {
			// Initialize WebDriver
		      WebDriver driver = new ChromeDriver();

		   // Load the URL
		      driver.get("http://leaftaps.com/opentaps/.");

		   // Maximize the browser window
		      driver.manage().window().maximize();

		   // Add an implicit wait to ensure the web page elements are fully loaded
		      WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		      //Enter the username and password
		      WebElement username = driver.findElement(By.id("username"));
		      username.sendKeys("demosalesmanager"); 
		      WebElement password = driver.findElement(By.id("password"));
		      password.sendKeys("crmsfa"); 

		      // Click the Login button
		      WebElement loginButton = driver.findElement(By.className("decorativeSubmit"));
		      loginButton.click();

		      // Click the "crm/sfa" link
		      WebElement crmLink = driver.findElement(By.linkText("CRM/SFA"));
		      crmLink.click();

		      //Click the "Leads" link
		      WebElement leadsLink = driver.findElement(By.linkText("Leads"));
		      leadsLink.click();

		      // Click on Create Lead
		        driver.findElement(By.linkText("Create Lead")).click();

		     // Enter  company name as "TestLeaf"
		        driver.findElement(By.xpath("//input[@id='createLeadForm_companyName']")).sendKeys("TestLeaf");

		     // Enter the FirstName using XPath
		        driver.findElement(By.xpath("//input[@id='createLeadForm_firstName']")).sendKeys("Arun");

		      // Enter the LastName using XPath
		        driver.findElement(By.xpath("//input[@id='createLeadForm_lastName']")).sendKeys("Natarajan");

		     // Enter the FirstName (Local) using XPath
		        driver.findElement(By.xpath("//input[@id='createLeadForm_firstNameLocal']")).sendKeys("Arun");

		     // Enter the Department using XPath
		        driver.findElement(By.xpath("//input[@id='createLeadForm_departmentName']")).sendKeys("Computer Software");

		       // Enter the Description using XPath
		        driver.findElement(By.xpath("//textarea[@id='createLeadForm_description']")).sendKeys("Selenium Automation");

		     // Enter the E-mail using XPath
		        driver.findElement(By.xpath("//input[@id='createLeadForm_primaryEmail']")).sendKeys("test@mail.com");
		        
		        // Select "ComputerSoftware" as the industry.
		        Select industryDropdown = new Select(driver.findElement(By.xpath("//select[@id='createLeadForm_industryEnumId']")));
		        industryDropdown.selectByVisibleText("Computer Software");

		        // Select "S-Corporation" as ownership using SelectByVisibleText. 
		        Select Ownership = new Select(driver.findElement(By.xpath("//select[@id='createLeadForm_ownershipEnumId']")));
		        Ownership.selectByVisibleText("S-Corporation");
		        
		       // Select "Employee" as the source using SelectByValue.
		        WebElement Empdropdown = driver.findElement(By.name("dataSourceId"));		       
		        Select select = new Select(Empdropdown); 
		        select.selectByValue("LEAD_EMPLOYEE");
		        WebElement selectedOption = select.getFirstSelectedOption(); 		        
		        System.out.println("Selected Option: " + selectedOption.getText());	        
		       
		        
		     // Select "eCommerce Site Internal Campaign" as the marketing campaign using SelectByIndex.		                
		        WebElement dropdown = driver.findElement(By.name("marketingCampaignId"));
		        Select select1 = new Select(dropdown);
		         select1.selectByIndex(6);	
		         WebElement selectedOption1 = select1.getFirstSelectedOption(); 
		         System.out.println("Selected Option1: " + selectedOption1.getText());
		         
		      // Select State/Province as New York using visible text
			        Select stateDropdown = new Select(driver.findElement(By.name("generalStateProvinceGeoId")));
			        stateDropdown.selectByVisibleText("Texas");			        
			        WebElement selectedOption2 = stateDropdown.getFirstSelectedOption(); 
			         System.out.println("Selected Option2: " + selectedOption2.getText()); 

		     // Click on the Create Button
		        driver.findElement(By.xpath("//input[@class='smallSubmit']")).click();

		     // Click on the Edit Button using its XPath
		        driver.findElement(By.xpath("//a[@class='subMenuButton' and text()='Edit']")).click();

		     // Locate the description field by its ID
		        WebElement descriptionField = driver.findElement(By.id("updateLeadForm_description"));

		    // Clear the text in the description field
		        descriptionField.clear();

	         //Important note
		     WebElement importantNoteField = driver.findElement(By.id("updateLeadForm_importantNote"));
	         importantNoteField.sendKeys("Lead creation completed");

	         // Locate the update button by its name attribute
	         WebElement updateButton = driver.findElement(By.name("submitButton"));

	         // Click on the update button
	         updateButton.click();

	         // Get the title of the current page
	         String pageTitle = driver.getTitle();
	         System.out.println("Page Title: " + pageTitle);
	         
	         // Verify that the account name is displayed correctly. 
	         WebElement accountNameElement = driver.findElement(By.id("ext-gen627"));
	         String displayedAccountName = accountNameElement.getText(); 
	         String expectedAccountName = "Arun Natarajan (TestLeaf)"; 
	         if(displayedAccountName.equals(expectedAccountName)) {
	        	 System.out.println("Account name is displayed correctly: " + displayedAccountName); 
	        	 } else {
	        	System.out.println("Account name is incorrect. Displayed: " + displayedAccountName + ", Expected: " + expectedAccountName);
	        	}
        

	      // Quit the entire browser session
	         driver.quit();

	}

	}

