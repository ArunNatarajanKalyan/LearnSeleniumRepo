package Week2.Day2;

	
	public class LibraryManagement {
		public static void main(String[] args) {
	        // Create an object of Library class
	        Library library = new Library();

	        // Call both methods from Library
	        String bookTitle = library.addBook("Life's Amazing Secrets: How to Find Balance and Purpose in Your Life");
	        System.out.println("Added Book Title in LibraryManagement: " + bookTitle);

	        library.issueBook();
	}
	}